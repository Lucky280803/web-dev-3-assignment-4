# SimpleNotes - Full-Stack MERN Notes Application

A clean, minimalist, and responsive full-stack Notes Application built with **Node.js, Express, MongoDB, and React (Vite)**.

Designed with simplicity in mind: **distraction-free, fast, light theme, with zero unnecessary animations, pins, or dark mode complexities**.

---

## 🌟 Key Features

- **Authentication & Security**: Secure User Registration and Login with password hashing (`bcryptjs`) and stateless JWT authorization (`jsonwebtoken`).
- **User-Isolated Notes**: Each user strictly sees, creates, edits, and deletes their own personal notes.
- **Full CRUD Support**:
  - **Create**: Add notes with titles, rich content, and comma-separated tags.
  - **Read**: View notes in a responsive, clean card layout.
  - **Update**: Edit notes inline anytime.
  - **Delete**: Remove notes with instant confirmation.
- **Search & Filter**:
  - Instant live debounced search across note titles and contents.
  - One-click tag filter chips to organize notes by topic (e.g. `#work`, `#study`, `#ideas`).
- **Clean & Simple UI**:
  - Light-only aesthetic with subtle borders and clear contrast.
  - No dark mode switches, no floating blobs or bouncing icons, no pinning clutter.

---

## 🛠️ Tech Stack

- **Frontend**: React 18, Vite, Plain Modern CSS (Modular & Responsive)
- **Backend**: Node.js, Express 4, RESTful API architecture
- **Database**: MongoDB with Mongoose ODM
- **Authentication**: JWT (JSON Web Tokens) & `bcryptjs`

---

## 📁 Project Architecture

```
Lokesh-Viva/
├── config/
│   └── db.js                 # MongoDB connection logic
├── models/
│   ├── user.model.js         # User Mongoose schema (name, email, password)
│   └── note.model.js         # Note Mongoose schema (title, content, tags, user)
├── middleware/
│   └── auth.middleware.js    # JWT verification middleware
├── routes/
│   ├── user.route.js         # Auth routes (/register, /login, /me)
│   └── note.route.js         # Note routes (CRUD + tags)
├── client/                   # React + Vite frontend
│   ├── src/
│   │   ├── components/       # Navbar, AuthForm, NoteCard, NoteEditor, Toast
│   │   ├── api.js            # Fetch wrapper with Bearer token
│   │   ├── App.jsx           # Main UI container & state
│   │   ├── index.css         # Clean light theme styling
│   │   └── main.jsx          # React entry point
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
├── .env.example              # Environment variables template
├── .env                      # Local environment configuration
├── package.json              # Root package with concurrently & scripts
├── server.js                 # Express server entry point
└── README.md
```

---

## 🚀 Getting Started

### 1. Prerequisites
- **Node.js** (v18 or newer)
- **MongoDB** (running locally on `mongodb://127.0.0.1:27017` or a MongoDB Atlas URI)

### 2. Environment Setup
Verify or adjust your `.env` file in the root folder:
```env
PORT=8080
MONGO_URI=mongodb://127.0.0.1:27017/simplenotes
JWT_SECRET=supersecretnotesjwtkey_2026_simple_notes
```

### 3. Installation
Install all dependencies for both the backend and the React frontend in one command:
```bash
npm run setup
```
*(Or manually: `npm install` and `cd client && npm install`)*

### 4. Running the Application

#### **Development Mode (API + React hot reload)**
```bash
npm run dev
```
- Backend runs on `http://localhost:8080`
- React frontend runs on `http://localhost:5173`

#### **Production Mode (Single Port)**
```bash
npm run build
npm start
```
- Serves the full app on `http://localhost:8080`

---

## 🔌 API Reference

### Authentication Routes
| Method | Endpoint | Auth | Description |
|---|---|---|---|
| `POST` | `/user/register` | No | Register a new account (`name`, `email`, `password`) |
| `POST` | `/user/login` | No | Login and obtain JWT token (`email`, `password`) |
| `GET` | `/user/me` | Yes | Get currently logged-in user profile |

### Notes Routes
| Method | Endpoint | Auth | Description |
|---|---|---|---|
| `GET` | `/notes?q=&tag=` | Yes | Fetch user's notes with optional search & tag filter |
| `GET` | `/notes/tags` | Yes | Fetch all unique tags used by the logged-in user |
| `POST` | `/notes` | Yes | Create a new note (`title`, `content`, `tags`) |
| `PUT` | `/notes/:id` | Yes | Update an existing note |
| `DELETE` | `/notes/:id` | Yes | Delete a note by ID |

*Pass the token in the request header:*
```http
Authorization: Bearer <your_jwt_token>
```
