import { useState, useEffect, useCallback } from "react";
import { api } from "./api";
import Navbar from "./components/Navbar";
import AuthForm from "./components/AuthForm";
import NoteCard from "./components/NoteCard";
import NoteEditor from "./components/NoteEditor";
import Toast from "./components/Toast";

export default function App() {
  const [token, setToken] = useState(localStorage.getItem("token") || "");
  const [userName, setUserName] = useState(localStorage.getItem("userName") || "");
  const [notes, setNotes] = useState([]);
  const [tags, setTags] = useState([]);
  const [selectedTag, setSelectedTag] = useState("");
  const [editingNote, setEditingNote] = useState(null); // null = closed, {} = new note, note object = edit
  const [toast, setToast] = useState(null);
  const [loading, setLoading] = useState(false);

  const showToast = (message, type = "info") => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  const handleLogin = (newToken, name) => {
    localStorage.setItem("token", newToken);
    localStorage.setItem("userName", name || "User");
    setToken(newToken);
    setUserName(name || "User");
    showToast(`Welcome back, ${name || "User"}!`, "success");
  };

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("userName");
    setToken("");
    setUserName("");
    setNotes([]);
    setTags([]);
    setEditingNote(null);
    showToast("Logged out successfully");
  };

  // Fetch user notes and tags
  const loadNotes = useCallback(async () => {
    if (!token) return;
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (selectedTag) {
        params.set("tag", selectedTag);
      }

      const notesData = await api(`/notes?${params.toString()}`);
      setNotes(notesData);

      const tagsData = await api("/notes/tags");
      setTags(tagsData);
    } catch (err) {
      if (err.status === 401) {
        handleLogout();
      } else {
        showToast(err.message || "Could not load notes", "error");
      }
    } finally {
      setLoading(false);
    }
  }, [token, selectedTag]);

  // Load notes on mount or when tag changes
  useEffect(() => {
    if (!token) return;
    loadNotes();
  }, [token, loadNotes]);

  // Delete note
  const handleDeleteNote = async (id) => {
    if (!window.confirm("Are you sure you want to delete this note?")) {
      return;
    }

    try {
      await api(`/notes/${id}`, "DELETE");
      showToast("Note deleted successfully", "success");
      if (editingNote && editingNote._id === id) {
        setEditingNote(null);
      }
      loadNotes();
    } catch (err) {
      showToast(err.message || "Failed to delete note", "error");
    }
  };

  if (!token) {
    return (
      <>
        <AuthForm onLogin={handleLogin} showToast={showToast} />
        <Toast toast={toast} />
      </>
    );
  }

  return (
    <>
      <Navbar
        userName={userName}
        onLogout={handleLogout}
      />

      <main className="main-content">
        {/* Control and Tag Filter Bar */}
        <div className="control-bar">
          <div className="tags-filter-bar">
            <button
              type="button"
              className={`tag-filter-btn ${selectedTag === "" ? "active" : ""}`}
              onClick={() => setSelectedTag("")}
            >
              All Notes
            </button>
            {tags.map((t) => (
              <button
                key={t}
                type="button"
                className={`tag-filter-btn ${selectedTag === t ? "active" : ""}`}
                onClick={() => setSelectedTag(selectedTag === t ? "" : t)}
              >
                #{t}
              </button>
            ))}
          </div>

          <button
            type="button"
            className="btn btn-primary"
            onClick={() => setEditingNote(editingNote ? null : {})}
          >
            {editingNote && !editingNote._id ? "Close Editor" : "+ New Note"}
          </button>
        </div>

        {/* Note Creator / Editor */}
        {editingNote && (
          <NoteEditor
            key={editingNote._id || "new"}
            initialNote={editingNote}
            onSaved={() => {
              setEditingNote(null);
              loadNotes();
            }}
            onCancel={() => setEditingNote(null)}
            showToast={showToast}
          />
        )}

        {/* Notes Count Info */}
        <div className="notes-header-status">
          {loading ? (
            <span>Loading notes...</span>
          ) : (
            <span>
              {notes.length} {notes.length === 1 ? "note" : "notes"}
              {selectedTag ? ` in #${selectedTag}` : ""}
            </span>
          )}
        </div>

        {/* Notes Grid */}
        {notes.length > 0 ? (
          <div className="notes-grid">
            {notes.map((note) => (
              <NoteCard
                key={note._id}
                note={note}
                onEdit={(n) => {
                  setEditingNote(n);
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
                onDelete={handleDeleteNote}
              />
            ))}
          </div>
        ) : !loading ? (
          <div className="empty-state">
            <svg
              className="empty-state-icon"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
              <polyline points="14 2 14 8 20 8"></polyline>
              <line x1="12" y1="18" x2="12" y2="12"></line>
              <line x1="9" y1="15" x2="15" y2="15"></line>
            </svg>
            <h3>No notes found</h3>
            <p>
              {selectedTag
                ? "No notes matched this tag filter."
                : "You don't have any notes yet. Create your first note above to get started!"}
            </p>
            {!editingNote && (
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => setEditingNote({})}
              >
                + Create Note
              </button>
            )}
          </div>
        ) : null}
      </main>

      <Toast toast={toast} />
    </>
  );
}
