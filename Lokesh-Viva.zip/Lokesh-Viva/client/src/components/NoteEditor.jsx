import { useState } from "react";
import { api } from "../api";

export default function NoteEditor({ initialNote = null, onSaved, onCancel, showToast }) {
  const [title, setTitle] = useState(initialNote?.title || "");
  const [content, setContent] = useState(initialNote?.content || "");
  const [tagsInput, setTagsInput] = useState((initialNote?.tags || []).join(", "));
  const [saving, setSaving] = useState(false);

  const isEditing = Boolean(initialNote?._id);

  const handleSubmit = async (e) => {
    e.preventDefault();

    const cleanTitle = title.trim();
    const cleanContent = content.trim();

    if (!cleanTitle && !cleanContent) {
      showToast("Please provide either a title or note content", "error");
      return;
    }

    setSaving(true);
    const tags = tagsInput
      .split(",")
      .map((t) => t.trim())
      .filter(Boolean);

    try {
      if (isEditing) {
        await api(`/notes/${initialNote._id}`, "PUT", {
          title: cleanTitle,
          content: cleanContent,
          tags,
        });
        showToast("Note updated successfully", "success");
      } else {
        await api("/notes", "POST", {
          title: cleanTitle,
          content: cleanContent,
          tags,
        });
        showToast("Note created successfully", "success");
      }
      onSaved();
    } catch (err) {
      showToast(err.message || "Failed to save note", "error");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="editor-card">
      <h3>{isEditing ? "Edit Note" : "Create New Note"}</h3>
      <form className="editor-form" onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Title (optional)"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          maxLength={150}
        />
        <textarea
          placeholder="Write your note content here..."
          value={content}
          onChange={(e) => setContent(e.target.value)}
          rows={5}
        />
        <input
          type="text"
          placeholder="Tags (comma-separated, e.g. college, study, ideas)"
          value={tagsInput}
          onChange={(e) => setTagsInput(e.target.value)}
        />
        <div className="editor-actions">
          <button type="button" className="btn btn-secondary" onClick={onCancel} disabled={saving}>
            Cancel
          </button>
          <button type="submit" className="btn btn-primary" disabled={saving}>
            {saving ? "Saving..." : isEditing ? "Update Note" : "Save Note"}
          </button>
        </div>
      </form>
    </div>
  );
}
