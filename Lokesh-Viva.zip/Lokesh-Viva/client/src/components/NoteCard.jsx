export default function NoteCard({ note, onEdit, onDelete }) {
  const formattedDate = note.updatedAt
    ? new Date(note.updatedAt).toLocaleDateString(undefined, {
        month: "short",
        day: "numeric",
        year: "numeric",
      })
    : "";

  return (
    <article className="note-card">
      <div>
        {note.title && <h4 className="note-card-title">{note.title}</h4>}
        {note.content && <p className="note-card-content">{note.content}</p>}

        {note.tags && note.tags.length > 0 && (
          <div className="note-card-tags">
            {note.tags.map((tag, idx) => (
              <span key={idx} className="tag-badge">
                #{tag}
              </span>
            ))}
          </div>
        )}
      </div>

      <div className="note-card-footer">
        <span>{formattedDate}</span>
        <div className="note-card-actions">
          <button
            type="button"
            className="btn btn-secondary btn-sm"
            onClick={() => onEdit(note)}
          >
            Edit
          </button>
          <button
            type="button"
            className="btn btn-danger-outline btn-sm"
            onClick={() => onDelete(note._id)}
          >
            Delete
          </button>
        </div>
      </div>
    </article>
  );
}
