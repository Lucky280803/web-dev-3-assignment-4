export default function Toast({ toast }) {
  if (!toast) return null;

  return (
    <div className={`toast-container ${toast.type === "error" ? "toast-error" : ""}`}>
      <span>{toast.message}</span>
    </div>
  );
}
