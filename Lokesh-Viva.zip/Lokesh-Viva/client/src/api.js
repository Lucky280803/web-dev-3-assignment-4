// API request helper with automated token handling
export async function api(endpoint, method = "GET", data = null) {
  const token = localStorage.getItem("token") || "";

  const options = {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
  };

  if (data && (method === "POST" || method === "PUT" || method === "PATCH")) {
    options.body = JSON.stringify(data);
  }

  const response = await fetch(endpoint, options);
  const result = await response.json().catch(() => ({}));

  if (!response.ok) {
    const error = new Error(result.msg || "Request failed");
    error.status = response.status;
    throw error;
  }

  return result;
}
