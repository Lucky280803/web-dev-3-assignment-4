const express = require("express");
const { noteModel } = require("../models/note.model");
const { auth } = require("../middleware/auth.middleware");

const noteRouter = express.Router();

// All note endpoints require authentication
noteRouter.use(auth);

// Helper to clean up tags
const sanitizeTags = (tags) => {
  if (!Array.isArray(tags)) {
    if (typeof tags === "string") {
      tags = tags.split(",");
    } else {
      return [];
    }
  }
  return [...new Set(tags.map((t) => String(t).trim().toLowerCase()).filter(Boolean))];
};

// GET /notes - List notes for the logged in user with optional tag filter
noteRouter.get("/", async (req, res) => {
  try {
    const { tag } = req.query;
    const filter = { user: req.userId };

    if (tag && tag.trim()) {
      filter.tags = tag.trim().toLowerCase();
    }

    const notes = await noteModel.find(filter).sort({ updatedAt: -1 });
    res.json(notes);
  } catch (error) {
    console.error("Fetch notes error:", error);
    res.status(500).json({ msg: "Failed to fetch notes" });
  }
});

// GET /notes/tags - Distinct tags for user's notes
noteRouter.get("/tags", async (req, res) => {
  try {
    const tags = await noteModel.distinct("tags", { user: req.userId });
    res.json(tags.filter(Boolean));
  } catch (error) {
    res.status(500).json({ msg: "Failed to fetch tags" });
  }
});

// GET /notes/:id - Get a single note
noteRouter.get("/:id", async (req, res) => {
  try {
    const note = await noteModel.findOne({ _id: req.params.id, user: req.userId });
    if (!note) {
      return res.status(404).json({ msg: "Note not found" });
    }
    res.json(note);
  } catch (error) {
    res.status(500).json({ msg: "Failed to fetch note" });
  }
});

// POST /notes - Create a new note
noteRouter.post("/", async (req, res) => {
  try {
    const { title, content, tags } = req.body || {};

    const cleanTitle = (title || "").trim();
    const cleanContent = (content || "").trim();

    if (!cleanTitle && !cleanContent) {
      return res.status(400).json({ msg: "Please enter a title or note content" });
    }

    const newNote = await noteModel.create({
      title: cleanTitle,
      content: cleanContent,
      tags: sanitizeTags(tags),
      user: req.userId,
    });

    res.status(201).json(newNote);
  } catch (error) {
    console.error("Create note error:", error);
    res.status(500).json({ msg: "Failed to create note" });
  }
});

// PUT or PATCH /notes/:id - Update an existing note
const updateNoteHandler = async (req, res) => {
  try {
    const { title, content, tags } = req.body || {};

    const updateData = {};
    if (title !== undefined) updateData.title = String(title).trim();
    if (content !== undefined) updateData.content = String(content).trim();
    if (tags !== undefined) updateData.tags = sanitizeTags(tags);

    const updatedNote = await noteModel.findOneAndUpdate(
      { _id: req.params.id, user: req.userId },
      updateData,
      { new: true, runValidators: true }
    );

    if (!updatedNote) {
      return res.status(404).json({ msg: "Note not found or unauthorized" });
    }

    res.json(updatedNote);
  } catch (error) {
    console.error("Update note error:", error);
    res.status(500).json({ msg: "Failed to update note" });
  }
};

noteRouter.put("/:id", updateNoteHandler);
noteRouter.patch("/:id", updateNoteHandler);

// DELETE /notes/:id - Delete a note
noteRouter.delete("/:id", async (req, res) => {
  try {
    const deleted = await noteModel.findOneAndDelete({
      _id: req.params.id,
      user: req.userId,
    });

    if (!deleted) {
      return res.status(404).json({ msg: "Note not found or unauthorized" });
    }

    res.json({ msg: "Note deleted successfully", id: req.params.id });
  } catch (error) {
    console.error("Delete note error:", error);
    res.status(500).json({ msg: "Failed to delete note" });
  }
});

module.exports = { noteRouter };
