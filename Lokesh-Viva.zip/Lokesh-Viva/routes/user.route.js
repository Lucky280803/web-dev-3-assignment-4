const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { userModel } = require("../models/user.model");
const { auth } = require("../middleware/auth.middleware");

const userRouter = express.Router();

// Register a new user
userRouter.post("/register", async (req, res) => {
  const { name, email, password } = req.body || {};

  if (!name || !name.trim()) {
    return res.status(400).json({ msg: "Name is required" });
  }
  if (!email || !email.trim()) {
    return res.status(400).json({ msg: "Email is required" });
  }
  if (!password) {
    return res.status(400).json({ msg: "Password is required" });
  }

  try {
    const existing = await userModel.findOne({ email: email.trim().toLowerCase() });
    if (existing) {
      return res.status(409).json({ msg: "An account with this email already exists. Please log in." });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await userModel.create({
      name: name.trim(),
      email: email.trim().toLowerCase(),
      password: hashedPassword,
    });

    res.status(201).json({ msg: "User registered successfully! Please log in." });
  } catch (error) {
    console.error("Register error:", error);
    res.status(500).json({ msg: "Failed to register user. Please try again." });
  }
});

// Log in user
userRouter.post("/login", async (req, res) => {
  const { email, password } = req.body || {};

  if (!email || !password) {
    return res.status(400).json({ msg: "Please provide both email and password" });
  }

  try {
    const user = await userModel.findOne({ email: email.trim().toLowerCase() });
    if (!user) {
      return res.status(404).json({ msg: "No account found with this email. Please register first." });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ msg: "Incorrect password. Please try again." });
    }

    const token = jwt.sign(
      { userId: user._id, email: user.email },
      process.env.JWT_SECRET || "default_jwt_secret_key",
      { expiresIn: "7d" }
    );

    res.json({
      msg: "Logged in successfully",
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
      },
    });
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ msg: "Failed to log in. Please try again." });
  }
});

// Get current user profile
userRouter.get("/me", auth, async (req, res) => {
  try {
    const user = await userModel.findById(req.userId).select("-password");
    if (!user) {
      return res.status(404).json({ msg: "User not found" });
    }
    res.json(user);
  } catch (error) {
    res.status(500).json({ msg: "Error fetching user details" });
  }
});

module.exports = { userRouter };
