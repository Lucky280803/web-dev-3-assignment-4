require("dotenv").config();
const path = require("path");
const express = require("express");
const cors = require("cors");
const { connectDB } = require("./config/db");
const { userRouter } = require("./routes/user.route");
const { noteRouter } = require("./routes/note.route");

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use("/user", userRouter);
app.use("/api/user", userRouter);
app.use("/api/users", userRouter);

app.use("/notes", noteRouter);
app.use("/api/notes", noteRouter);

// Health check endpoint
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", message: "Simple Notes API is active and running." });
});

// Serve frontend in production if built
const clientDistPath = path.join(__dirname, "client", "dist");
app.use(express.static(clientDistPath));

app.get("*", (req, res, next) => {
  if (
    req.path.startsWith("/api") ||
    req.path.startsWith("/user") ||
    req.path.startsWith("/notes")
  ) {
    return next();
  }
  res.sendFile(path.join(clientDistPath, "index.html"), (err) => {
    if (err) {
      res.status(200).send("<h3>Simple Notes App API is online. Run the client via Vite or npm run dev.</h3>");
    }
  });
});

// Centralized error handling
app.use((err, req, res, next) => {
  console.error("Unhandled Error:", err);
  const isDataError = ["CastError", "ValidationError"].includes(err.name);
  res.status(isDataError ? 400 : 500).json({
    msg: isDataError ? "Invalid data provided" : "An unexpected server error occurred",
  });
});

const PORT = process.env.PORT || 8080;

app.listen(PORT, async () => {
  console.log(`Server is running on port ${PORT}`);
  await connectDB();
});
